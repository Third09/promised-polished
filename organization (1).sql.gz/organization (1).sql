-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 14, 2024 at 04:37 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `orgconnect`
--

-- --------------------------------------------------------

--
-- Table structure for table `organization`
--

CREATE TABLE `organization` (
  `org_id` int(11) NOT NULL,
  `org_name` varchar(255) DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `org_acronym` varchar(20) DEFAULT NULL,
  `org_email` varchar(50) DEFAULT NULL,
  `long_description` text DEFAULT NULL,
  `short_description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `organization`
--

INSERT INTO `organization` (`org_id`, `org_name`, `logo`, `org_acronym`, `org_email`, `long_description`, `short_description`) VALUES
(1, 'Sustainable Campus Initiative (SCI) ', '', 'SCI', 'sci@gmail.com', 'Dedicated to promoting sustainability on campus, SCI organizes events and projects focused on reducing the university’s carbon footprint and encouraging eco-friendly habits among students.\n', 'The Sustainability Campus Initiative (SCI) is dedicated to fostering eco-consciousness by organizing events and projects that reduce the university\'s carbon footprint and promote sustainable habits among students.'),
(2, 'Future Business Leaders Society (FBLS)', '', 'FBLS', 'fbls@gmail.com', 'Aimed at grooming future entrepreneurs and business leaders, FBLS offers workshops, mentorship, and networking opportunities for students interested in business and leadership.', 'The Future Business Leaders Society (FBLS) focuses on developing aspiring entrepreneurs and business leaders through workshops, mentorship, and networking opportunities tailored for students passionate about business and leadership.'),
(3, 'Campus Media Organization (CMO)', '', 'CMO', 'cmo@gmail.com', 'The official media arm of the university, CMO manages the campus newspaper, radio, and online platforms. It provides students with hands-on experience in journalism, broadcasting, and digital media.', 'The Campus Media Organization (CMO) serves as the university\'s official media arm, overseeing the campus newspaper, radio, and online platforms. It offers students practical experience in journalism, broadcasting, and digital media.\n\n\n\n\n\n\nThe Campus Media Organization (CMO) serves as the university\'s official media arm, overseeing the campus newspaper, radio, and online platforms. It offers students practical experience in journalism, broadcasting, and digital media.\n\n\n\n\n\n\nThe Campus Media Organization (CMO) serves as the university\'s official media arm, overseeing the campus newspaper, radio, and online platforms. It offers students practical experience in journalism, broadcasting, and digital media.\n\n\n\n\n\n\n'),
(4, 'Health and Wellness  Society (HWS)', '', 'HWS', 'hws@gmail.com', 'This organization promotes the physical, mental, and emotional well-being of students through workshops, fitness activities, and counseling services.', 'The Student Wellness Organization promotes students\' physical, mental, and emotional well-being through workshops, fitness activities, and counseling services.\n\n\n\n\n\n\nThe Student Wellness Organization promotes students\' physical, mental, and emotional well-being through workshops, fitness activities, and counseling services.\n\n\n\n\n\n\nThe Student Wellness Organization promotes students\' physical, mental, and emotional well-being through workshops, fitness activities, and counseling services.\n\n\n\n\n\n\n'),
(5, 'Cultural Arts Society (CAS)', '', 'CAS', 'cas@gmail.com', 'CAS celebrates Philippine culture and arts, organizing events like performances, art exhibits, and cultural workshops to showcase the talents of students and preserve local traditions.\r\n', 'The Cultural and Arts Society (CAS) celebrates Philippine culture and arts by organizing events, performances, and workshops that showcase and preserve the nation\'s rich heritage.\n\n\n\n\n\n\n\n'),
(6, 'Tech Support Group (TSG)', '', 'TSG', 'tsg@gmail.com', 'TSG provides technical assistance to students and staff, helping with issues related to computers, software, and other IT needs within the university.', 'The Technical Support Group (TSG) offers technical assistance to students and staff, addressing issues related to computers, software, and other IT needs within the university.'),
(7, 'Young Entrepreneurs Network (YEN)', '', 'YEN', 'yen@gmail.com', 'YEN helps aspiring student entrepreneurs develop business skills through mentorship, business plan competitions, and networking events with local startups and established businesses.', 'The Young Entrepreneurs Network (YEN) supports aspiring student entrepreneurs by offering mentorship, business plan competitions, and networking opportunities with local startups and established businesses.'),
(8, 'Environmental Advocacy Group (EAG)', '', 'EAG', 'eag@gmail.com', 'EAG raises awareness about environmental issues and works on initiatives such as waste reduction, biodiversity conservation, and climate change action in the university and surrounding communities.', 'The Environmental Awareness Group (EAG) advocates for environmental issues by implementing initiatives like waste reduction, biodiversity conservation, and climate change action within the university and its surrounding communities.'),
(9, 'Student Volunteers for Literacy (SVL)', '', 'SVL', 'svl@gmail.com', 'SVL promotes literacy by organizing reading programs, book drives, and tutoring sessions for underprivileged children in nearby communities.', 'Students for Volunteer Literacy (SVL) promotes literacy by organizing reading programs, book drives, and tutoring sessions for underprivileged children in nearby communities.'),
(10, 'Gaming and Esports Society (GES)', '', 'GES', 'ges@gmail.com', 'GES provides a space for students who are passionate about video games and esports. The group organizes gaming tournaments, streaming events, and discussions on the gaming industry.', 'The Gaming and Esports Society (GES) offers a space for students passionate about video games and esports. The group organizes gaming tournaments, streaming events, and discussions on the gaming industry.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `organization`
--
ALTER TABLE `organization`
  ADD PRIMARY KEY (`org_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `organization`
--
ALTER TABLE `organization`
  MODIFY `org_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
